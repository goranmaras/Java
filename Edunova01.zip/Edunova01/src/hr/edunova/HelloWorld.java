package hr.edunova;

/**
 * Dokumentacija klase
 * @author Profesor
 *
 */
public class HelloWorld {

	
	// jedna linija
	
	/*
	 * Više
	 * linija
	 */
	
	/**
	 * Ovo je dokumentacija metode
	 * @param args
	 */
	public static void main(String[] args) {
		//System.out.print("Hello\n");
		//ili
		System.out.println("Hello");
		System.out.print("Osijek");
		System.out.println();
		
		System.out.println("I rekao je \"Super\"");
		
		System.out.println("čšćđžČŠĆĐŽ");
		
		System.err.println("Prikazuje crveno u Eclipse konzoli");
		
	}

}
